package com.cts.irctc;

import com.cts.irctc.skeletonvalidator.SkeletonValidator;

public class SkeleTest {

	public static void main(String[] args) {
	SkeletonValidator sk=new SkeletonValidator();

	}

}
